// MobileMenuButton.js
import React from "react";

function MobileMenuButton() {
  return (
    <div className="absolute inset-y-0 left-0 flex items-center sm:hidden">
      {/* ... (same as your original code) */}
    </div>
  );
}

export default MobileMenuButton;
