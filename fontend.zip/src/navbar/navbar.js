import React, { useState, useEffect } from "react";
import MobileMenuButton from "./mobilenavar";
import DesktopMenu from "./desktop";

function Navbar() {
  const [userDetails, setUserDetails] = useState(null);

  useEffect(() => {
    // Check if the user is logged in by retrieving user details from local storage
    const storedUserDetails = localStorage.getItem("userDetails");
    if (storedUserDetails) {
      setUserDetails(JSON.parse(storedUserDetails));
    }
  }, []);

  const handleLogout = () => {
    // Implement logout functionality and clear user details from local storage
    localStorage.removeItem("userDetails");
    setUserDetails(null);
  };

  return (
    <nav className="bg-gray-800">
      <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
        {/* <MobileMenuButton /> */}
        <DesktopMenu />
      </div>
    </nav>
  );
}

export default Navbar;
