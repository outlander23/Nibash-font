// App.js
import React from "react";
// import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import Login from "./auth/Login";
import Register from "./auth/Register";
import Navbar from "./navbar/navbar";
import Dashboard from "./dashbord/Dashboard";
import Profile from "./profile/profile";
import Transaction from "./transactions/transactions";

function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <Switch>
          <Route path="/register" component={Register} />
          <Route path="/login" component={Login} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/profile" component={Profile} />
          <Route path="/transaction" component={Transaction} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
