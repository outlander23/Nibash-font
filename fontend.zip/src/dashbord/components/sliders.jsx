import React from 'react'

export default function Sliders() {
  return (
    <div>sliders</div>
  )
}
