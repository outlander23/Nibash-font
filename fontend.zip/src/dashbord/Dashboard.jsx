import React from 'react'
import Sliders from './components/sliders'

export default function Dashboard() {
  return (
    <div>
      <h1>Hi</h1>
       <Sliders />
    </div>
  )
}
